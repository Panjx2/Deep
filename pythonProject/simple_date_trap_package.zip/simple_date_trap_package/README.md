# Synthetic Benchmark - to make GPT trip but not fall

## Overview

This package contains a synthetic data-analysis benchmark designed to test whether a model can correctly combine:

- near-duplicate record handling,
- mixed date parsing,
- chronological event processing,
- month-local refund cancellation,
- replacement-vs-add adjustment semantics,
- and final ranking over active customers.

The task is fully synthetic with some handcrafted edge cases for the sake of evaluational clarity

The model is asked to return the five active customers with the highest final adjusted spend.

## Files

- `generator.py` — generates the synthetic dataset
- `dataset/customers.csv`
- `dataset/events.csv`
- `dataset/monthly_adjustments.csv`
- `prompt.txt` — the benchmark prompt
- `ground_truth.py` — computes the exact correct answer
- `correct_answer.json` — exact answer produced by the ground-truth script
- `ground_truth_details.json` — human-readable explanation of the correct answer
- `evaluator.py` — scores one or multiple model outputs
- `score_summary.json` — aggregated evaluation results
- `diagnostic_report.json` — diagnostic analysis of repeated model outputs

## Output pipeline

1. **Generate the dataset**
   - Run `generator.py`.
   - This creates:
     - `dataset/customers.csv`
     - `dataset/events.csv`
     - `dataset/monthly_adjustments.csv` :contentReference[oaicite:0]{index=0}

2. **Compute the exact answer**
   - Run `ground_truth.py`.
   - This computes the exact top 5 and writes:
     - `correct_answer.json`
     - `ground_truth_details.json` 

3. **Query the model**
   - Give the model `prompt.txt` plus the three CSV files.
   - Save each model response as a separate JSON file inside `dataset/`, for example:
     - `model_output_1.json`
     - `model_output_2.json`
     - `model_output_3.json`
     - etc. :contentReference[oaicite:2]{index=2}

4. **Evaluate repeated runs**
   - Run `evaluator.py`.
   - It reads all files matching `dataset/model_output*.json`, computes scores against the exact answer, and writes:
     - `diagnostic_report.json`
     - `diagnostic_report.txt` 

5. **Read the final benchmark result**
   - The main aggregate numbers are under `summary` in `diagnostic_report.json`, including:
     - number of runs
     - mean / median / min / max score
     - standard deviation
     - exact top 5
     - per-run outputs and scores. :contentReference[oaicite:4]{index=4}

6. **Inspect failure modes**
   - `diagnostic_report.json` also contains `diagnoses`, which group repeated wrong answers and try to match them to likely failure modes such as:
     - wrong date parsing
     - adding `replacement_total` instead of replacing
     - other structured mistakes. 
## Task

The model receives three CSV files:

- `customers.csv`
- `events.csv`
- `monthly_adjustments.csv`
It must return:

```text
[id1,id2,id3,id4,id5]
as specified in prompt.txt

